import React, { useState, useRef, useEffect } from 'react';
import { Upload, Play, Pause, Save, FileVideo, Youtube, Plus, Trash2, Clock, Moon, Sun } from 'lucide-react';

// Types for our subtitle entries
interface SubtitleEntry {
  id: number;
  startTime: number; // in seconds
  endTime: number; // in seconds
  text: string;
}

function formatTime(timeInSeconds: number): string {
  const hours = Math.floor(timeInSeconds / 3600);
  const minutes = Math.floor((timeInSeconds % 3600) / 60);
  const seconds = Math.floor(timeInSeconds % 60);
  const milliseconds = Math.floor((timeInSeconds % 1) * 1000);
  
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')},${milliseconds.toString().padStart(3, '0')}`;
}

function parseTime(timeString: string): number {
  // Handle incomplete time strings by padding with zeros
  if (timeString.length < 8) {
    timeString = timeString.padStart(8, '0');
  }
  
  // Add milliseconds if not present
  if (!timeString.includes(',')) {
    timeString += ',000';
  }
  
  const [hms, ms] = timeString.split(',');
  const [hours, minutes, seconds] = hms.split(':').map(Number);
  const milliseconds = Number(ms) || 0;
  
  return hours * 3600 + minutes * 60 + seconds + milliseconds / 1000;
}

function parseSRT(srtContent: string): SubtitleEntry[] {
  const entries: SubtitleEntry[] = [];
  const blocks = srtContent.trim().split(/\r?\n\r?\n/);
  
  blocks.forEach((block, index) => {
    const lines = block.split(/\r?\n/);
    if (lines.length >= 3) {
      const timeMatch = lines[1].match(/(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/);
      if (timeMatch) {
        const startTime = parseTime(timeMatch[1]);
        const endTime = parseTime(timeMatch[2]);
        const text = lines.slice(2).join('\n');
        
        entries.push({
          id: index + 1,
          startTime,
          endTime,
          text
        });
      }
    }
  });
  
  return entries;
}

function generateSRT(subtitles: SubtitleEntry[]): string {
  return subtitles
    .sort((a, b) => a.startTime - b.startTime)
    .map((subtitle, index) => {
      return `${index + 1}\n${formatTime(subtitle.startTime)} --> ${formatTime(subtitle.endTime)}\n${subtitle.text}`;
    })
    .join('\n\n');
}

// Custom time input component
interface TimeInputProps {
  value: string;
  onChange: (value: string) => void;
  className?: string;
  onClick?: (e: React.MouseEvent) => void;
}

const TimeInput: React.FC<TimeInputProps> = ({ value, onChange, className, onClick }) => {
  // Track cursor position
  const [cursorPosition, setCursorPosition] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Apply cursor position after render
  useEffect(() => {
    if (cursorPosition !== null && inputRef.current) {
      inputRef.current.setSelectionRange(cursorPosition, cursorPosition);
    }
  }, [cursorPosition, value]);
  
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Get current cursor position
    const currentPosition = e.currentTarget.selectionStart || 0;
    
    // Handle special keys
    if (e.key === 'Backspace') {
      // Don't delete colons
      if (currentPosition === 3 || currentPosition === 6) {
        e.preventDefault();
        // Move cursor left
        setCursorPosition(currentPosition - 1);
      }
    } else if (e.key === 'Delete') {
      // Don't delete colons
      if (currentPosition === 2 || currentPosition === 5) {
        e.preventDefault();
        // Move cursor right
        setCursorPosition(currentPosition + 1);
      }
    } else if (e.key === 'ArrowLeft') {
      // Skip over colons when moving left
      if (currentPosition === 3 || currentPosition === 6) {
        e.preventDefault();
        setCursorPosition(currentPosition - 1);
      }
    } else if (e.key === 'ArrowRight') {
      // Skip over colons when moving right
      if (currentPosition === 2 || currentPosition === 5) {
        e.preventDefault();
        setCursorPosition(currentPosition + 1);
      }
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    const currentPosition = e.target.selectionStart || 0;
    
    // Only allow digits and colons
    if (!/^[\d:]*$/.test(newValue)) {
      return;
    }
    
    // Ensure format is maintained (HH:MM:SS)
    let formattedValue = newValue;
    
    // Always maintain the format with colons at positions 2 and 5
    const digits = formattedValue.replace(/:/g, '');
    
    // Rebuild the string with colons in the right positions
    formattedValue = '';
    for (let i = 0; i < digits.length; i++) {
      if (i === 2 || i === 4) {
        formattedValue += ':';
      }
      formattedValue += digits[i];
    }
    
    // Ensure we don't exceed 8 characters (HH:MM:SS)
    formattedValue = formattedValue.slice(0, 8);
    
    // Ensure each part is valid
    const parts = formattedValue.split(':');
    let isValid = true;
    
    if (parts[0] && parseInt(parts[0]) > 99) isValid = false; // Hours (0-99)
    if (parts[1] && parseInt(parts[1]) > 59) isValid = false; // Minutes (0-59)
    if (parts[2] && parseInt(parts[2]) > 59) isValid = false; // Seconds (0-59)
    
    if (isValid) {
      onChange(formattedValue);
      
      // Calculate new cursor position
      let newCursorPos = currentPosition;
      
      // If we're adding a digit that would push a colon, move cursor forward
      if (
        (currentPosition === 2 && newValue.length >= currentPosition && !newValue.includes(':')) ||
        (currentPosition === 5 && newValue.length >= currentPosition && newValue.split(':').length < 3)
      ) {
        newCursorPos++;
      }
      
      // If we're at a position where a colon was added, adjust cursor
      if (formattedValue.length > newValue.length) {
        const colonsBefore = (newValue.substring(0, currentPosition).match(/:/g) || []).length;
        const colonsAfter = (formattedValue.substring(0, currentPosition + 1).match(/:/g) || []).length;
        if (colonsAfter > colonsBefore) {
          newCursorPos++;
        }
      }
      
      setCursorPosition(newCursorPos);
    }
  };
  
  return (
    <input
      ref={inputRef}
      type="text"
      value={value}
      onChange={handleChange}
      onKeyDown={handleKeyDown}
      onClick={onClick}
      className={className}
      placeholder="00:00:00"
      maxLength={8}
    />
  );
};

function App() {
  const [mediaType, setMediaType] = useState<'youtube' | 'local'>('youtube');
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [youtubeId, setYoutubeId] = useState<string>('');
  const [localMediaUrl, setLocalMediaUrl] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [subtitles, setSubtitles] = useState<SubtitleEntry[]>([]);
  const [selectedSubtitle, setSelectedSubtitle] = useState<number | null>(null);
  const [youtubeApiReady, setYoutubeApiReady] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  
  // For time input editing
  const [startTimeInput, setStartTimeInput] = useState<{[key: number]: string}>({});
  const [endTimeInput, setEndTimeInput] = useState<{[key: number]: string}>({});
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const youtubePlayerRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const srtInputRef = useRef<HTMLInputElement>(null);
  const timeUpdateIntervalRef = useRef<number | null>(null);
  const youtubeContainerRef = useRef<HTMLDivElement>(null);

  // Initialize dark mode from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('srt-editor-theme');
    if (savedTheme === 'dark') {
      setDarkMode(true);
    } else if (savedTheme === null) {
      // Check system preference if no saved preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setDarkMode(prefersDark);
    }
  }, []);

  // Apply dark mode class to document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    // Save preference to localStorage
    localStorage.setItem('srt-editor-theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  // Initialize YouTube API
  useEffect(() => {
    // Check if script is already loaded
    if (document.querySelector('script[src="https://www.youtube.com/iframe_api"]')) {
      if (window.YT && window.YT.Player) {
        setYoutubeApiReady(true);
      }
      return;
    }

    // Load YouTube API
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    if (firstScriptTag && firstScriptTag.parentNode) {
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    } else {
      document.head.appendChild(tag);
    }

    // Define the onYouTubeIframeAPIReady function
    window.onYouTubeIframeAPIReady = () => {
      setYoutubeApiReady(true);
    };

    return () => {
      // Clean up interval
      if (timeUpdateIntervalRef.current) {
        clearInterval(timeUpdateIntervalRef.current);
      }
    };
  }, []);

  // Handle media type change
  useEffect(() => {
    // Clean up YouTube player when switching to local media
    if (mediaType === 'local' && youtubePlayerRef.current) {
      try {
        // Pause the video first
        if (youtubePlayerRef.current.pauseVideo) {
          youtubePlayerRef.current.pauseVideo();
        }
        
        // Clear the interval
        if (timeUpdateIntervalRef.current) {
          clearInterval(timeUpdateIntervalRef.current);
          timeUpdateIntervalRef.current = null;
        }
        
        // Destroy the player
        if (youtubePlayerRef.current.destroy) {
          youtubePlayerRef.current.destroy();
        }
        
        youtubePlayerRef.current = null;
        
        // Reset the container for future use
        if (youtubeContainerRef.current) {
          youtubeContainerRef.current.innerHTML = '';
        } else {
          // Create a new container if it doesn't exist
          const container = document.getElementById('youtube-player');
          if (container) {
            container.innerHTML = '';
          }
        }
      } catch (error) {
        console.error("Error cleaning up YouTube player:", error);
      }
    }
    
    // Reset playback state when switching media types
    setIsPlaying(false);
    setCurrentTime(0);
    setDuration(0);
  }, [mediaType]);

  // Initialize or update YouTube player when youtubeId changes
  useEffect(() => {
    if (youtubeId && youtubeApiReady && mediaType === 'youtube') {
      initYouTubePlayer();
    }
    
    return () => {
      // Clean up interval
      if (timeUpdateIntervalRef.current) {
        clearInterval(timeUpdateIntervalRef.current);
        timeUpdateIntervalRef.current = null;
      }
    };
  }, [youtubeId, youtubeApiReady, mediaType]);

  // Update current time for local video
  useEffect(() => {
    if (mediaType === 'local' && videoRef.current) {
      const updateTime = () => {
        setCurrentTime(videoRef.current?.currentTime || 0);
      };
      
      const videoElement = videoRef.current;
      videoElement.addEventListener('timeupdate', updateTime);
      videoElement.addEventListener('durationchange', () => {
        setDuration(videoElement.duration);
      });
      
      return () => {
        videoElement.removeEventListener('timeupdate', updateTime);
      };
    }
  }, [mediaType]);

  // Display current subtitle
  useEffect(() => {
    const currentSubtitle = subtitles.find(
      sub => currentTime >= sub.startTime && currentTime <= sub.endTime
    );
    
    if (currentSubtitle) {
      setSelectedSubtitle(currentSubtitle.id);
    }
  }, [currentTime, subtitles]);

  // Initialize time input values when subtitles change
  useEffect(() => {
    const newStartTimeInputs: {[key: number]: string} = {};
    const newEndTimeInputs: {[key: number]: string} = {};
    
    subtitles.forEach(sub => {
      newStartTimeInputs[sub.id] = formatTime(sub.startTime).substring(0, 8);
      newEndTimeInputs[sub.id] = formatTime(sub.endTime).substring(0, 8);
    });
    
    setStartTimeInput(newStartTimeInputs);
    setEndTimeInput(newEndTimeInputs);
  }, [subtitles]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timeUpdateIntervalRef.current) {
        clearInterval(timeUpdateIntervalRef.current);
      }
      
      // Safely destroy YouTube player if it exists
      if (youtubePlayerRef.current && typeof youtubePlayerRef.current.destroy === 'function') {
        try {
          youtubePlayerRef.current.destroy();
        } catch (error) {
          console.error("Error destroying YouTube player:", error);
        }
      }
    };
  }, []);

  const toggleTheme = () => {
    setDarkMode(!darkMode);
  };

  const initYouTubePlayer = () => {
    // Clean up existing player if it exists
    if (youtubePlayerRef.current && typeof youtubePlayerRef.current.destroy === 'function') {
      try {
        youtubePlayerRef.current.destroy();
      } catch (error) {
        console.error("Error destroying YouTube player:", error);
      }
      youtubePlayerRef.current = null;
    }

    // Clear any existing interval
    if (timeUpdateIntervalRef.current) {
      clearInterval(timeUpdateIntervalRef.current);
      timeUpdateIntervalRef.current = null;
    }

    // Make sure the container exists
    const container = document.getElementById('youtube-player');
    if (!container) {
      console.error("YouTube player container not found");
      return;
    }

    // Clear the container
    container.innerHTML = '';

    // Create a new player
    try {
      youtubePlayerRef.current = new window.YT.Player('youtube-player', {
        height: '360',
        width: '640',
        videoId: youtubeId,
        playerVars: {
          enablejsapi: 1,
          origin: window.location.origin,
          rel: 0
        },
        events: {
          onReady: (event: any) => {
            setDuration(event.target.getDuration());
          },
          onStateChange: (event: any) => {
            setIsPlaying(event.data === window.YT.PlayerState.PLAYING);
            
            // Start time update interval when playing
            if (event.data === window.YT.PlayerState.PLAYING) {
              // Clear any existing interval first
              if (timeUpdateIntervalRef.current) {
                clearInterval(timeUpdateIntervalRef.current);
              }
              
              // Set new interval
              timeUpdateIntervalRef.current = window.setInterval(() => {
                if (youtubePlayerRef.current && typeof youtubePlayerRef.current.getCurrentTime === 'function') {
                  try {
                    const currentTime = youtubePlayerRef.current.getCurrentTime();
                    setCurrentTime(currentTime);
                  } catch (error) {
                    console.error("Error getting current time:", error);
                    clearInterval(timeUpdateIntervalRef.current!);
                    timeUpdateIntervalRef.current = null;
                  }
                }
              }, 100) as unknown as number;
            } else if (timeUpdateIntervalRef.current) {
              clearInterval(timeUpdateIntervalRef.current);
              timeUpdateIntervalRef.current = null;
            }
          }
        }
      });
    } catch (error) {
      console.error("Error initializing YouTube player:", error);
    }
  };

  const handleYoutubeUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value;
    setYoutubeUrl(url);
    
    // Extract YouTube ID from URL
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    
    if (match && match[1]) {
      setYoutubeId(match[1]);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setLocalMediaUrl(url);
      setMediaType('local');
    }
  };

  const handleSrtUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        const parsedSubtitles = parseSRT(content);
        setSubtitles(parsedSubtitles);
      };
      reader.readAsText(file);
    }
  };

  const togglePlayPause = () => {
    if (mediaType === 'youtube' && youtubePlayerRef.current) {
      if (isPlaying) {
        try {
          youtubePlayerRef.current.pauseVideo();
        } catch (error) {
          console.error("Error pausing YouTube video:", error);
        }
      } else {
        try {
          youtubePlayerRef.current.playVideo();
        } catch (error) {
          console.error("Error playing YouTube video:", error);
        }
      }
    } else if (mediaType === 'local' && videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickPosition = (e.clientX - rect.left) / rect.width;
    const newTime = clickPosition * duration;
    
    if (mediaType === 'youtube' && youtubePlayerRef.current) {
      try {
        youtubePlayerRef.current.seekTo(newTime);
        setCurrentTime(newTime);
      } catch (error) {
        console.error("Error seeking YouTube video:", error);
      }
    } else if (mediaType === 'local' && videoRef.current) {
      videoRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const addSubtitle = () => {
    const newId = subtitles.length > 0 ? Math.max(...subtitles.map(s => s.id)) + 1 : 1;
    const newSubtitle: SubtitleEntry = {
      id: newId,
      startTime: currentTime,
      endTime: currentTime + 3, // Default 3 seconds duration
      text: ''
    };
    
    setSubtitles([...subtitles, newSubtitle]);
    setSelectedSubtitle(newId);
    
    // Initialize time inputs for the new subtitle
    setStartTimeInput({
      ...startTimeInput,
      [newId]: formatTime(currentTime).substring(0, 8)
    });
    
    setEndTimeInput({
      ...endTimeInput,
      [newId]: formatTime(currentTime + 3).substring(0, 8)
    });
  };

  const updateSubtitle = (id: number, field: keyof SubtitleEntry, value: any) => {
    setSubtitles(subtitles.map(sub => 
      sub.id === id ? { ...sub, [field]: value } : sub
    ));
  };

  const handleStartTimeChange = (id: number, value: string) => {
    setStartTimeInput({
      ...startTimeInput,
      [id]: value
    });
    
    // Only update the actual subtitle if the format is valid
    if (/^\d{2}:\d{2}:\d{2}$/.test(value)) {
      const timeInSeconds = parseTime(value);
      updateSubtitle(id, 'startTime', timeInSeconds);
    }
  };

  const handleEndTimeChange = (id: number, value: string) => {
    setEndTimeInput({
      ...endTimeInput,
      [id]: value
    });
    
    // Only update the actual subtitle if the format is valid
    if (/^\d{2}:\d{2}:\d{2}$/.test(value)) {
      const timeInSeconds = parseTime(value);
      updateSubtitle(id, 'endTime', timeInSeconds);
    }
  };

  const deleteSubtitle = (id: number) => {
    setSubtitles(subtitles.filter(sub => sub.id !== id));
    if (selectedSubtitle === id) {
      setSelectedSubtitle(null);
    }
    
    // Clean up time inputs
    const newStartTimeInput = { ...startTimeInput };
    const newEndTimeInput = { ...endTimeInput };
    delete newStartTimeInput[id];
    delete newEndTimeInput[id];
    setStartTimeInput(newStartTimeInput);
    setEndTimeInput(newEndTimeInput);
  };

  const downloadSRT = () => {
    const srtContent = generateSRT(subtitles);
    const blob = new Blob([srtContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'subtitles.srt';
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 100);
  };

  const jumpToSubtitle = (startTime: number) => {
    if (mediaType === 'youtube' && youtubePlayerRef.current) {
      try {
        youtubePlayerRef.current.seekTo(startTime);
        setCurrentTime(startTime);
      } catch (error) {
        console.error("Error seeking YouTube video:", error);
      }
    } else if (mediaType === 'local' && videoRef.current) {
      videoRef.current.currentTime = startTime;
      setCurrentTime(startTime);
    }
  };

  const handleMediaTypeChange = (type: 'youtube' | 'local') => {
    if (type !== mediaType) {
      setMediaType(type);
    }
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gray-900' : 'bg-gray-100'} flex flex-col transition-colors duration-200`}>
      {/* Header */}
      <header className="dark:bg-gray-800 bg-white shadow-sm p-4 flex justify-between items-center transition-colors duration-200">
        <h1 className="text-xl font-semibold dark:text-white text-gray-800">SRT Editor</h1>
        <button 
          onClick={toggleTheme} 
          className="p-2 rounded-full dark:bg-gray-700 dark:text-gray-200 bg-gray-200 text-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors duration-200"
          aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
        >
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
      </header>
      
      <div className="flex flex-col md:flex-row flex-1 p-4 gap-4">
        {/* Left Panel - Media Player */}
        <div className="w-full md:w-2/3 dark:bg-gray-800 bg-white rounded-lg shadow-md p-4 flex flex-col transition-colors duration-200">
          {/* Media Type Selector */}
          <div className="flex mb-4 gap-2">
            <button 
              className={`flex items-center px-4 py-2 rounded-md transition-colors duration-200 ${
                mediaType === 'youtube' 
                  ? 'bg-blue-500 text-white' 
                  : 'dark:bg-gray-700 dark:text-gray-200 bg-gray-200 text-gray-700'
              }`}
              onClick={() => handleMediaTypeChange('youtube')}
            >
              <Youtube size={18} className="mr-2" />
              YouTube
            </button>
            <button 
              className={`flex items-center px-4 py-2 rounded-md transition-colors duration-200 ${
                mediaType === 'local' 
                  ? 'bg-blue-500 text-white' 
                  : 'dark:bg-gray-700 dark:text-gray-200 bg-gray-200 text-gray-700'
              }`}
              onClick={() => handleMediaTypeChange('local')}
            >
              <FileVideo size={18} className="mr-2" />
              Local Media
            </button>
          </div>
          
          {/* Media Input */}
          {mediaType === 'youtube' ? (
            <div className="mb-4">
              <input 
                type="text" 
                placeholder="Enter YouTube URL" 
                value={youtubeUrl} 
                onChange={handleYoutubeUrlChange}
                className="w-full p-2 dark:bg-gray-700 dark:text-white dark:border-gray-600 border border-gray-300 rounded-md transition-colors duration-200"
              />
            </div>
          ) : (
            <div className="mb-4">
              <button 
                onClick={() => fileInputRef.current?.click()} 
                className="flex items-center px-4 py-2 dark:bg-gray-700 dark:text-gray-200 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors duration-200"
              >
                <Upload size={18} className="mr-2" />
                Upload Media
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                accept="video/*,audio/*" 
                className="hidden" 
              />
            </div>
          )}
          
          {/* Media Player */}
          <div className="flex-1 flex items-center justify-center bg-black rounded-md overflow-hidden">
            {mediaType === 'youtube' ? (
              youtubeId ? (
                <div id="youtube-player" ref={youtubeContainerRef} className="w-full h-full"></div>
              ) : (
                <div className="text-white">Enter a YouTube URL to start</div>
              )
            ) : (
              localMediaUrl ? (
                <video 
                  ref={videoRef} 
                  src={localMediaUrl} 
                  className="max-w-full max-h-full" 
                  controls={false}
                  onPlay={() => setIsPlaying(true)}
                  onPause={() => setIsPlaying(false)}
                ></video>
              ) : (
                <div className="text-white">Upload a media file to start</div>
              )
            )}
          </div>
          
          {/* Media Controls */}
          <div className="mt-4">
            <div className="flex items-center mb-2">
              <button 
                onClick={togglePlayPause} 
                className="p-2 dark:bg-gray-700 dark:text-gray-200 bg-gray-200 rounded-full mr-2 hover:bg-gray-300 dark:hover:bg-gray-600 disabled:opacity-50 transition-colors duration-200"
                disabled={!youtubeId && mediaType === 'youtube' || !localMediaUrl && mediaType === 'local'}
              >
                {isPlaying ? <Pause size={18} /> : <Play size={18} />}
              </button>
              <span className="text-sm dark:text-gray-300 text-gray-600 transition-colors duration-200">
                {formatTime(currentTime).substring(0, 8)} / {formatTime(duration).substring(0, 8)}
              </span>
            </div>
            
            {/* Timeline */}
            <div 
              className="h-2 dark:bg-gray-700 bg-gray-200 rounded-full cursor-pointer relative transition-colors duration-200"
              onClick={handleTimelineClick}
            >
              <div 
                className="absolute top-0 left-0 h-full bg-blue-500 rounded-full"
                style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
              ></div>
              
              {/* Subtitle markers */}
              {subtitles.map(sub => (
                <div 
                  key={sub.id}
                  className={`absolute top-0 h-full w-1 ${selectedSubtitle === sub.id ? 'bg-red-500' : 'bg-green-500'}`}
                  style={{ left: `${duration > 0 ? (sub.startTime / duration) * 100 : 0}%` }}
                  title={sub.text}
                ></div>
              ))}
            </div>
          </div>
        </div>
        
        {/* Right Panel - Subtitle Editor */}
        <div className="w-full md:w-1/3 dark:bg-gray-800 bg-white rounded-lg shadow-md p-4 flex flex-col transition-colors duration-200">
          {/* SRT Upload */}
          <div className="mb-4 flex justify-between">
            <button 
              onClick={() => srtInputRef.current?.click()} 
              className="flex items-center px-4 py-2 dark:bg-gray-700 dark:text-gray-200 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors duration-200"
            >
              <Upload size={18} className="mr-2" />
              Import SRT
            </button>
            <input 
              type="file" 
              ref={srtInputRef} 
              onChange={handleSrtUpload} 
              accept=".srt" 
              className="hidden" 
            />
            
            <button 
              onClick={downloadSRT} 
              className="flex items-center px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 disabled:opacity-50 transition-colors duration-200"
              disabled={subtitles.length === 0}
            >
              <Save size={18} className="mr-2" />
              Export SRT
            </button>
          </div>
          
          {/* Add Subtitle Button */}
          <button 
            onClick={addSubtitle} 
            className="mb-4 flex items-center justify-center px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors duration-200"
          >
            <Plus size={18} className="mr-2" />
            Add Subtitle at Current Time
          </button>
          
          {/* Subtitle List */}
          <div className="flex-1 overflow-y-auto">
            {subtitles.length === 0 ? (
              <div className="text-center dark:text-gray-400 text-gray-500 py-8 transition-colors duration-200">
                No subtitles yet. Import an SRT file or add subtitles manually.
              </div>
            ) : (
              <div className="space-y-4">
                {subtitles
                  .sort((a, b) => a.startTime - b.startTime)
                  .map(subtitle => (
                    <div 
                      key={subtitle.id} 
                      className={`p-3 rounded-md transition-colors duration-200 ${
                        selectedSubtitle === subtitle.id 
                          ? 'border-blue-500 dark:bg-blue-900/30 bg-blue-50 border' 
                          : 'dark:border-gray-700 dark:bg-gray-700 border-gray-200 border'
                      }`}
                      onClick={() => setSelectedSubtitle(subtitle.id)}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <div className="text-sm dark:text-gray-400 text-gray-500 transition-colors duration-200">#{subtitle.id}</div>
                        <div className="flex gap-2">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              jumpToSubtitle(subtitle.startTime);
                            }}
                            className="p-1 text-blue-500 dark:hover:bg-gray-600 hover:bg-blue-100 rounded transition-colors duration-200"
                            title="Jump to this subtitle"
                          >
                            <Clock size={16} />
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteSubtitle(subtitle.id);
                            }}
                            className="p-1 text-red-500 dark:hover:bg-gray-600 hover:bg-red-100 rounded transition-colors duration-200"
                            title="Delete subtitle"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 mb-2">
                        <div className="flex-1">
                          <label className="block text-xs dark:text-gray-400 text-gray-500 mb-1 transition-colors duration-200">Start</label>
                          <TimeInput 
                            value={startTimeInput[subtitle.id] || formatTime(subtitle.startTime).substring(0, 8)} 
                            onChange={(value) => handleStartTimeChange(subtitle.id, value)}
                            className="w-full p-1 text-sm dark:bg-gray-700 dark:text-white dark:border-gray-600 border border-gray-300 rounded transition-colors duration-200"
                            onClick={(e) => e.stopPropagation()}
                          />
                        </div>
                        <div className="flex-1">
                          <label className="block text-xs dark:text-gray-400 text-gray-500 mb-1 transition-colors duration-200">End</label>
                          <TimeInput 
                            value={endTimeInput[subtitle.id] || formatTime(subtitle.endTime).substring(0, 8)} 
                            onChange={(value) => handleEndTimeChange(subtitle.id, value)}
                            className="w-full p-1 text-sm dark:bg-gray-700 dark:text-white dark:border-gray-600 border border-gray-300 rounded transition-colors duration-200"
                            onClick={(e) => e.stopPropagation()}
                          />
                        </div>
                      </div>
                      
                      <textarea 
                        value={subtitle.text} 
                        onChange={(e) => updateSubtitle(subtitle.id, 'text', e.target.value)}
                        className="w-full p-2 dark:bg-gray-700 dark:text-white dark:border-gray-600 border border-gray-300 rounded resize-none transition-colors duration-200"
                        rows={2}
                        placeholder="Enter subtitle text"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Add type definition for YouTube API
declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

export default App;