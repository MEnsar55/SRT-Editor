# SRT Editor

A modern subtitle editor for creating and editing SRT files. This application allows you to create, edit, and synchronize subtitles with video content from YouTube or local media files.

## Features

- Support for both YouTube videos and local media files
- Import and export SRT files
- Add, edit, and delete subtitles
- Precise time control with a custom time input system
- Dark mode support
- Timeline visualization with subtitle markers
- Responsive design for desktop and mobile

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/srt-editor.git
cd srt-editor
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## Usage

### YouTube Videos

1. Select the YouTube tab
2. Paste a YouTube URL in the input field
3. Use the player controls to navigate the video
4. Add subtitles at specific timestamps

### Local Media

1. Select the Local Media tab
2. Click "Upload Media" to select a video or audio file
3. Use the player controls to navigate the media
4. Add subtitles at specific timestamps

### Working with Subtitles

- Click "Add Subtitle at Current Time" to create a new subtitle at the current playback position
- Edit the start and end times using the time input fields
- Enter the subtitle text in the textarea
- Click the clock icon to jump to a specific subtitle
- Click the trash icon to delete a subtitle
- Use "Import SRT" to load an existing SRT file
- Use "Export SRT" to download your subtitles as an SRT file

## License

MIT